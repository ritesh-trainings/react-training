import React, { Component } from 'react';
import MyCardCatalog from './MyCardCatalog';

export default class Widgets extends Component {
    render() {
        return (
            <MyCardCatalog />
        )
    }
}




