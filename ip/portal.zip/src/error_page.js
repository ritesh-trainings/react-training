import React from 'react';

const ErrorPage = () => {
    return (
        <div className="container text-center">
            <h5>Error</h5>
        </div>
    )
}

export default ErrorPage;